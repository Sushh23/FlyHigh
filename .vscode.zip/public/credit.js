// document.addEventListener('DOMContentLoaded', function () {
//     const card = document.querySelector('.card-inner');

//     card.addEventListener('click', function () {
//         console.log("Here");
//         card.classList.toggle('is-flipped');
//     });
// // });
// $('.card-inner').click(function()
// {
//     $(this).closest('.card-inner').toggleClass('animate');
//     $(this).css('transform,rotateY(180deg)');
// })


